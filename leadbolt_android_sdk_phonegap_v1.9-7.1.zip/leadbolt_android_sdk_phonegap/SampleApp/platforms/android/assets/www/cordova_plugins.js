cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/cordova-plugin-whitelist/whitelist.js",
        "id": "cordova-plugin-whitelist.whitelist",
        "pluginId": "cordova-plugin-whitelist",
        "runs": true
    },
    {
        "file": "plugins/com.apptracker.phonegap.android/www/AppTracker.js",
        "id": "com.apptracker.phonegap.android.AppTracker",
        "pluginId": "com.apptracker.phonegap.android",
        "clobbers": [
            "AppTracker"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.2.0",
    "com.apptracker.phonegap.android": "0.0.1"
}
// BOTTOM OF METADATA
});